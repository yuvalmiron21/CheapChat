export function Privacy() {
    return <div>Privacy Policy Placeholder</div>;
}